const AppConfig = {
    BASE_URL:"http://localhost:8000/",
    API_BASE_URL:"http://localhost:8000/api/v1/",
    SUB_DOMAIN:"http://localhost:3000/",
}

export default AppConfig;