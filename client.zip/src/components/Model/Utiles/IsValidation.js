const IsItemValue = (value) =>{
    if(value && value.lenght){
        return true
    }else{
        false
    }
}

export default IsItemValue;