import React from 'react'

function PageLoader() {
  return (
    <div> 

  
        <img src="all image/loader.gif" alt="not found" style={{width:"112%",marginLeft:"-2rem",marginBottom:"-10rem",overflowX:"hidden"}}/>
    </div>
  
  )
}

export default PageLoader;