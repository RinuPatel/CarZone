import './serverError.css'

const ServerError = () => {
    return (
        <>

            <div style={{ marginTop: "5rem" }}>
                <div class="page-404">
                    <img src="/all image/server-error.png" alt="" />
                </div>
            </div>
        </>
    )
}
export default ServerError;